package br.ufsc.ine5611;

public class SignerException extends Exception {
    public SignerException(String s) {
        super(s);
    }
}
